# AFN Channel (Create: AFN)
![AFN Serial Transceiver](item:afntisbridge:afn_serial_transceiver)

The **AFN Serial Transceiver** connects a serial port module to a channel of
the **Create: Advanced Frequency Network**. Place up to two AFN frequency
boards into the transceiver (right-click while holding a board; sneak
right-click with an empty hand to eject), then point a serial port module at
it from any side.

It is crafted by placing a TIS-3D **Controller** above an AFN **Mailbox** in
a crafting grid.

The channel is operated in TRANSCEIVE mode: the module can read the value
currently received on the channel and transmit values onto it.

## Reading (channel → casing)

While the channel carries a signal, the module reads a *frame* of values. The
frame is rebuilt whenever the received value or strength changes, and reading
restarts at the beginning of the frame.

- Word 0: **kind** — 0 none, 1 real, 2 text, 3 boolean
- Word 1: **length** — number of payload words
- Word 2: **strength** — current signal strength, 0..15
- Word 3: **revision** — low 16 bits of the value revision; changes when a new
  value was received
- Payload:
    - real: 4 words per component (IEEE 754 double, big endian); multiple
      components are stored consecutively
    - text: UTF-16BE code units, `length` of them, no terminator
    - boolean: 1 word, 0 or 1

After the last word of the frame, reads return 0.

## Writing (casing → channel)

Writes are command-prefixed. The first word selects a command; the remaining
words are the operand. Each command is applied as soon as its operand is
complete.

- `1` **strength** — 1 word: transmitted strength, `word & 0xF`
- `2` **real** — 4 words: IEEE 754 double, big endian; sent as REAL value
- `3` **text** — any number of words, terminated by `0x0000`; sent as TEXT
- `4` **boolean** — 1 word: nonzero means true
- `5` **clear** — no operand; clears the transmitted typed value

Non-finite doubles are sent as 0.0. Text is filtered to the AFN character
policy (no section sign, no control characters other than newline, at most
1024 code points). Unknown command words are ignored.

A typed value (REAL / TEXT / BOOL) is broadcast with the strength previously
set via the STRENGTH command; if no STRENGTH command was issued (or the last
one was 0), full strength 15 is used instead, so the value is always actually
transmitted. The CLEAR command removes the typed value while keeping the
current strength.

Attach only **one** serial port module per transceiver; concurrent writers
would interleave their commands.

## Example: transmit strength 15

```
MOV 1 DOWN # command: STRENGTH
MOV 15 DOWN
```

## Example: transmit the REAL value 1.0

IEEE 754 bits of 1.0 are 0x3FF0000000000000, sent as four big endian words:

```
MOV 2 DOWN     # command: REAL
MOV 0x3FF0 DOWN
MOV 0x0000 DOWN
MOV 0x0000 DOWN
MOV 0x0000 DOWN
```

A reader on a transceiver tuned to the same frequency then sees the frame
`[1, 4, 15, revision, 0x3FF0, 0, 0, 0]` (kind REAL, 4 payload words,
strength 15, revision, then the double).

## Example: clear the transmitted value

```
MOV 5 DOWN # command: CLEAR, no operand
```

The typed value is removed while the strength is kept; readers see a frame
with kind 0. To take the channel off the air completely, additionally send
the STRENGTH command with 0.

## Example: read the header, forward strength

```
LOOP:
MOV UP ACC # kind
MOV UP ACC # length
MOV UP ACC # strength -> keep in ACC
MOV UP ACC # revision
```
