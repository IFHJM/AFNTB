package com.afntisbridge;

import com.mojang.logging.LogUtils;
import li.cil.manual.api.prefab.provider.NamespaceDocumentProvider;
import li.cil.manual.api.util.Constants;
import li.cil.tis3d.api.serial.SerialInterfaceProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.RegisterEvent;
import org.slf4j.Logger;

/**
 * AFN Serial Bridge - bridges TIS-3D serial port modules to Create: AFN channels.
 *
 * <p>The mod registers a {@link li.cil.tis3d.api.serial.SerialInterfaceProvider} named
 * {@code afntisbridge:afn_transceiver} into TIS-3D's
 * {@code tis3d:serial_interface_provider} registry. The provider matches the
 * {@link SerialTransceiverBlockEntity} added by this mod, which in turn opens a
 * channel endpoint through {@code com.createafn.api.channel.AFNChannelApi}.</p>
 *
 * <p>A document provider is registered into Markdown Manual's registry so the
 * protocol page referenced from the TIS-3D manual (link {@code afn_channel.md})
 * resolves to {@code assets/afntisbridge/doc/&lt;lang&gt;/protocols/afn_channel.md}.
 * This registration lives in the common entry class on purpose: the manual
 * registry only exists on the client, so the event never fires on a dedicated
 * server and no client-only class is loaded there.</p>
 */
@Mod(AfnTisBridge.MOD_ID)
public final class AfnTisBridge {

    public static final String MOD_ID = "afntisbridge";
    public static final Logger LOGGER = LogUtils.getLogger();

    private static final ResourceLocation SERIAL_PROVIDER_ID =
        ResourceLocation.fromNamespaceAndPath(MOD_ID, "afn_transceiver");

    private static final ResourceLocation DOCUMENT_PROVIDER_ID =
        ResourceLocation.fromNamespaceAndPath(MOD_ID, "afn_protocol_docs");

    public AfnTisBridge(final IEventBus modEventBus) {
        ModRegistry.register(modEventBus);

        modEventBus.addListener(this::registerSerialInterfaceProvider);
        modEventBus.addListener(this::registerDocumentProvider);
        modEventBus.addListener(this::addCreative);
        modEventBus.addListener(this::registerCapabilities);
    }

    /**
     * Registers the document provider serving our manual pages into Markdown
     * Manual's {@code markdown_manual:document_provider} registry. The manual
     * falls back from the current language to {@code en_us} automatically.
     */
    private void registerDocumentProvider(final RegisterEvent event) {
        if (event.getRegistryKey().equals(Constants.DOCUMENT_PROVIDER_REGISTRY)) {
            event.register(Constants.DOCUMENT_PROVIDER_REGISTRY, DOCUMENT_PROVIDER_ID,
                () -> new NamespaceDocumentProvider(MOD_ID, "doc"));
            LOGGER.info("[AFN Serial Bridge] Registered manual document provider {}", DOCUMENT_PROVIDER_ID);
        }
    }

    /**
     * Plug our provider into TIS-3D's serial protocol registry. The registry is
     * created by TIS-3D via architectury; on NeoForge it surfaces as a regular
     * mod registry, so {@link RegisterEvent} can be used directly.
     */
    private void registerSerialInterfaceProvider(final RegisterEvent event) {
        if (event.getRegistryKey().equals(SerialInterfaceProvider.REGISTRY)) {
            event.register(SerialInterfaceProvider.REGISTRY, SERIAL_PROVIDER_ID,
                AfnSerialInterfaceProvider::new);
            LOGGER.info("[AFN Serial Bridge] Registered serial protocol {}", SERIAL_PROVIDER_ID);
        }
    }

    private void addCreative(final BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == net.minecraft.world.item.CreativeModeTabs.FUNCTIONAL_BLOCKS
            || event.getTabKey() == net.minecraft.world.item.CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(ModRegistry.TRANSCEIVER_ITEM);
        }
    }

    private void registerCapabilities(final RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK,
            ModRegistry.TRANSCEIVER_BLOCK_ENTITY.get(),
            (blockEntity, side) -> blockEntity.getBoardAccess());
    }
}
