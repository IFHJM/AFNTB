package com.afntisbridge;

import com.createafn.api.channel.AFNChannelApi;
import com.createafn.api.channel.ChannelEndpoint;
import com.createafn.api.channel.ChannelFrequencyPair;
import com.createafn.api.channel.ChannelIdentity;
import com.createafn.api.channel.ChannelMode;
import com.createafn.api.channel.ChannelReception;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

import java.util.UUID;

/**
 * Server-side owner of the AFN {@link ChannelEndpoint}.
 *
 * <p>The block entity keeps two frequency board slots. Whenever the boards
 * change, the endpoint's frequencies are refreshed. Every server tick the
 * endpoint is polled; the current reception is decoded into a short frame
 * (see {@link AfnSerialInterface#encodeFrame}) that serial port modules read
 * through the TIS-3D serial interface.</p>
 *
 * <p>All AFN API access is guarded against linkage errors so a missing or
 * outdated create_afn cannot crash a world that merely contains this block.</p>
 */
public final class SerialTransceiverBlockEntity extends BlockEntity implements SerialChannelOwner {

    public static final int BOARD_SLOTS = 2;

    private static final String TAG_DEVICE_ID = "afnDeviceId";
    private static final String TAG_BOARDS = "boards";

    private final ItemStackHandler boards = new ItemStackHandler(BOARD_SLOTS) {
        @Override
        public boolean isItemValid(final int slot, final ItemStack stack) {
            return SerialTransceiverBlockEntity.isFrequencyBoard(stack);
        }

        @Override
        protected void onContentsChanged(final int slot) {
            SerialTransceiverBlockEntity.this.boardsDirty = true;
            SerialTransceiverBlockEntity.this.setChanged();
        }
    };

    /** Stable per-device id; persisted so the AFN channel identity survives reloads. */
    private UUID deviceId;

    /** Server-side only channel endpoint. Created lazily in {@link #serverTick()}. */
    private ChannelEndpoint endpoint;

    /** Bumped whenever the endpoint is recreated; folds into the reception key. */
    private int endpointGeneration;

    /** Set when the AFN API is unusable; prevents retry spam every tick. */
    private boolean endpointFailed;

    private boolean boardsDirty = true;

    // Cached reception state, exposed to serial interfaces.
    private short[] frame = new short[0];
    private int frameVersion;
    private long lastReceptionKey = Long.MIN_VALUE;
    private boolean receptionAvailable;

    public SerialTransceiverBlockEntity(final BlockPos position, final BlockState state) {
        super(ModRegistry.TRANSCEIVER_BLOCK_ENTITY.get(), position, state);
    }

    public static boolean isFrequencyBoard(final ItemStack stack) {
        try {
            return AFNChannelApi.isFrequencyBoard(stack);
        } catch (final LinkageError | RuntimeException ignored) {
            return false;
        }
    }

    // ------------------------------------------------------------------ tick

    public void serverTick() {
        if (this.boardsDirty) {
            this.boardsDirty = false;
            this.refreshFrequencies();
        }
        if (this.endpoint == null && !this.endpointFailed) {
            this.createEndpoint();
        }
        if (this.endpoint != null) {
            this.updateReception();
        }
    }

    private void createEndpoint() {
        if (!(this.getLevel() instanceof final ServerLevel serverLevel)) {
            return;
        }
        try {
            if (!AFNChannelApi.supports(1, 1)) {
                this.failEndpoint("create_afn channel API 1.1+ is required, endpoint disabled", null);
                return;
            }
            this.endpoint = AFNChannelApi.createEndpoint(
                serverLevel, this.getBlockPos(), this.currentFrequencies(),
                ChannelMode.TRANSCEIVE, this.identity());
            this.endpointGeneration++;
            this.endpoint.attach();
        } catch (final LinkageError | RuntimeException e) {
            this.failEndpoint("Failed to open AFN channel endpoint", e);
        }
    }

    private void refreshFrequencies() {
        if (this.endpoint == null) {
            return;
        }
        try {
            this.endpoint.setFrequencies(this.currentFrequencies());
        } catch (final LinkageError | RuntimeException e) {
            this.failEndpoint("Failed to update AFN channel frequencies", e);
        }
    }

    private void updateReception() {
        final ChannelReception reception;
        try {
            reception = this.endpoint.reception();
        } catch (final LinkageError | RuntimeException ignored) {
            return;
        }
        final boolean available = reception.powered();
        long key = (this.endpointGeneration * 0x9E3779B97F4A7C15L)
            ^ (reception.changeVersion() << 4)
            ^ (long) reception.strength();
        if (!reception.hasValue()) {
            key = ~key;
        }
        if (key != this.lastReceptionKey || available != this.receptionAvailable) {
            this.lastReceptionKey = key;
            this.receptionAvailable = available;
            this.frame = AfnSerialInterface.encodeFrame(reception);
            this.frameVersion++;
        }
    }

    private void failEndpoint(final String message, final Throwable cause) {
        this.endpointFailed = true;
        this.endpoint = null;
        AfnTisBridge.LOGGER.error("[AFN Serial Bridge] {} at {}", message, this.getBlockPos(), cause);
    }

    private ChannelIdentity identity() {
        if (this.deviceId == null) {
            this.deviceId = UUID.randomUUID();
            this.setChanged();
        }
        return ChannelIdentity.named(this.deviceId, "serial");
    }

    private ChannelFrequencyPair currentFrequencies() {
        return ChannelFrequencyPair.of(
            this.boards.getStackInSlot(0),
            this.boards.getStackInSlot(1));
    }

    // ------------------------------------------- serial interface accessors

    /** @return the decoded reception frame consumed by {@link AfnSerialInterface#peek()}. */
    public short[] serialFrame() {
        return this.frame;
    }

    /** @return version of {@link #serialFrame()}; incremented whenever the frame changes. */
    public int serialFrameVersion() {
        return this.frameVersion;
    }

    /** @return whether the channel currently carries a signal (strength &gt; 0). */
    public boolean isReceptionAvailable() {
        return this.receptionAvailable;
    }

    /** @return whether the serial port module may write to the channel. */
    public boolean isTransmitReady() {
        final ChannelEndpoint current = this.endpoint;
        return current != null && !current.closed() && current.attached() && current.configured();
    }

    @Override
    public boolean isStillValid() {
        return !this.isRemoved();
    }

    @Override
    public void applyTransmittedStrength(final int strength) {
        final ChannelEndpoint current = this.endpoint;
        if (current == null || !current.attached()) {
            return;
        }
        try {
            current.setTransmittedStrength(strength & 0xF);
            AfnTisBridge.LOGGER.info("[AFN Serial Bridge] Strength set to {} at {}",
                strength & 0xF, this.getBlockPos().toShortString());
        } catch (final LinkageError | RuntimeException ignored) {
        }
    }

    @Override
    public void applyTransmittedValue(final com.createafn.api.channel.ChannelValue value) {
        final ChannelEndpoint current = this.endpoint;
        if (current == null || !current.attached()) {
            AfnTisBridge.LOGGER.warn("[AFN Serial Bridge] Value dropped: channel not attached at {}",
                this.getBlockPos().toShortString());
            return;
        }
        try {
            // A typed value must ride on a non-zero signal strength, otherwise
            // the AFN network treats the channel as powered down and neither
            // the strength nor the value reaches any receiver. Default to full
            // strength when no explicit STRENGTH command was issued before.
            int strength = current.transmittedStrength();
            if (strength == 0) {
                strength = 15;
            }
            current.setTransmission(strength, value);
            AfnTisBridge.LOGGER.info("[AFN Serial Bridge] Transmitted {} value at strength {} at {}",
                value.kind(), strength, this.getBlockPos().toShortString());
        } catch (final LinkageError | RuntimeException e) {
            AfnTisBridge.LOGGER.warn("[AFN Serial Bridge] Rejected transmitted value: {}", e.toString());
        }
    }

    @Override
    public void applyClearTransmittedValue() {
        final ChannelEndpoint current = this.endpoint;
        if (current == null || !current.attached()) {
            AfnTisBridge.LOGGER.warn("[AFN Serial Bridge] Clear dropped: channel not attached at {}",
                this.getBlockPos().toShortString());
            return;
        }
        try {
            current.clearTransmittedValue();
            AfnTisBridge.LOGGER.info("[AFN Serial Bridge] Cleared transmitted value at {}",
                this.getBlockPos().toShortString());
        } catch (final LinkageError | RuntimeException e) {
            AfnTisBridge.LOGGER.warn("[AFN Serial Bridge] Rejected clear: {}", e.toString());
        }
    }

    // ------------------------------------------------------------ inventory

    public IItemHandler getBoardAccess() {
        return this.boards;
    }

    public boolean hasFreeBoardSlot() {
        for (int slot = 0; slot < this.boards.getSlots(); slot++) {
            if (this.boards.getStackInSlot(slot).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** @return whether the stack was inserted into the first free board slot. */
    public boolean insertBoard(final ItemStack stack) {
        for (int slot = 0; slot < this.boards.getSlots(); slot++) {
            if (this.boards.getStackInSlot(slot).isEmpty()) {
                this.boards.setStackInSlot(slot, stack.copyWithCount(1));
                return true;
            }
        }
        return false;
    }

    /** @return the most recently inserted board stack, or an empty stack. */
    public ItemStack ejectBoard() {
        for (int slot = this.boards.getSlots() - 1; slot >= 0; slot--) {
            final ItemStack stack = this.boards.getStackInSlot(slot);
            if (!stack.isEmpty()) {
                return this.boards.extractItem(slot, stack.getCount(), false);
            }
        }
        return ItemStack.EMPTY;
    }

    public void dropBoards() {
        final Level level = this.getLevel();
        if (level == null) {
            return;
        }
        final BlockPos position = this.getBlockPos();
        for (int slot = 0; slot < this.boards.getSlots(); slot++) {
            final ItemStack stack = this.boards.getStackInSlot(slot);
            if (!stack.isEmpty()) {
                Containers.dropItemStack(level,
                    position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5, stack);
            }
            this.boards.setStackInSlot(slot, ItemStack.EMPTY);
        }
    }

    // ------------------------------------------------------------ lifecycle

    /** Permanently closes the channel endpoint (block destroyed). */
    public void shutdown() {
        if (this.endpoint != null) {
            try {
                this.endpoint.close();
            } catch (final LinkageError | RuntimeException ignored) {
            }
            this.endpoint = null;
        }
        this.receptionAvailable = false;
        this.frame = new short[0];
        this.frameVersion++;
    }

    /** Temporarily detaches the endpoint (chunk unloaded); re-attaches on the next tick. */
    private void detachEndpoint() {
        if (this.endpoint != null) {
            try {
                this.endpoint.detach();
            } catch (final LinkageError | RuntimeException ignored) {
            }
        }
    }

    @Override
    public void setRemoved() {
        this.shutdown();
        super.setRemoved();
    }

    @Override
    public void onChunkUnloaded() {
        this.detachEndpoint();
        super.onChunkUnloaded();
    }

    // ---------------------------------------------------------- persistence

    @Override
    protected void saveAdditional(final CompoundTag tag, final HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (this.deviceId != null) {
            tag.putUUID(TAG_DEVICE_ID, this.deviceId);
        }
        tag.put(TAG_BOARDS, this.boards.serializeNBT(registries));
    }

    @Override
    public void loadAdditional(final CompoundTag tag, final HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.hasUUID(TAG_DEVICE_ID)) {
            this.deviceId = tag.getUUID(TAG_DEVICE_ID);
        }
        if (tag.contains(TAG_BOARDS)) {
            this.boards.deserializeNBT(registries, tag.getCompound(TAG_BOARDS));
        }
        this.boardsDirty = true;
    }
}
