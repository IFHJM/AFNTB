package com.afntisbridge;

import com.createafn.api.channel.ChannelReceivedValue;
import com.createafn.api.channel.ChannelReception;
import com.createafn.api.channel.ChannelValue;
import li.cil.tis3d.api.serial.SerialInterface;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.Optional;

/**
 * The TIS-3D serial interface backed by an AFN channel.
 *
 * <h2>Read stream (AFN channel → casing)</h2>
 *
 * <p>The current reception is encoded as a frame of shorts:</p>
 * <pre>
 *   word 0: kind     (0 = none, 1 = real, 2 = text, 3 = bool)
 *   word 1: length   (payload word count)
 *   word 2: strength (0..15, current received signal strength)
 *   word 3: revision (low 16 bits of the AFN value revision)
 *   payload:
 *     real: 4 words per IEEE 754 double, big endian, one word group per component
 *     text: UTF-16BE code units, no terminator (length = code unit count)
 *     bool: 1 word (0 or 1)
 * </pre>
 *
 * <p>Whenever a new value (or strength change) is received the frame is
 * rebuilt and the read cursor restarts at word 0. Past the end of the frame
 * {@link #peek()} returns 0.</p>
 *
 * <h2>Write stream (casing → AFN channel)</h2>
 *
 * <p>Writes are command-prefixed; the first short selects the command, the
 * remaining shorts are the operand:</p>
 * <pre>
 *   1 (STRENGTH): 1 word  -> transmitted strength = word &amp; 0xF
 *   2 (REAL):     4 words -> IEEE 754 double, big endian, sent as REAL value
 *   3 (TEXT):     n words + 0x0000 terminator -> sent as TEXT value
 *   4 (BOOL):     1 word  -> nonzero sent as BOOLEAN true
 *   5 (CLEAR):    none    -> clears the transmitted typed value
 * </pre>
 *
 * <p>Non-finite doubles are transmitted as 0.0. Text is sanitized to the AFN
 * character policy (no section sign, no control characters except newline,
 * max 1024 code points) before transmission. Unknown command words are
 * ignored. Because every command is atomic, attach a single serial port
 * module per transceiver; concurrent writers would interleave.</p>
 */
public final class AfnSerialInterface implements SerialInterface {

    // Read frame header word 0: value kind.
    public static final short KIND_NONE = 0;
    public static final short KIND_REAL = 1;
    public static final short KIND_TEXT = 2;
    public static final short KIND_BOOL = 3;

    /** Number of header words in a read frame. */
    public static final int HEADER_WORDS = 4;

    // Write commands.
    public static final short CMD_STRENGTH = 1;
    public static final short CMD_REAL = 2;
    public static final short CMD_TEXT = 3;
    public static final short CMD_BOOL = 4;
    public static final short CMD_CLEAR = 5;

    /** AFN text limit is 1024 code points; buffer up to 2048 UTF-16 units. */
    private static final int TEXT_BUFFER_LIMIT = 2048;

    private static final String TAG_CURSOR = "cursor";
    private static final String TAG_FRAME_VERSION = "frameVersion";
    private static final String TAG_COMMAND = "command";
    private static final String TAG_ACCUMULATOR = "accumulator";
    private static final String TAG_ACCUMULATOR_INDEX = "accumulatorIndex";
    private static final String TAG_TEXT = "text";

    private final SerialChannelOwner owner;
    private final Level level;
    private final BlockPos position;

    /** Frame version last observed; a change restarts the read cursor. */
    private int frameVersion = -1;
    private int cursor = 0;

    // Write state machine.
    private short pendingCommand = 0;
    private final short[] accumulator = new short[4];
    private int accumulatorIndex = 0;
    private final StringBuilder textBuffer = new StringBuilder();

    AfnSerialInterface(final SerialChannelOwner owner, final Level level, final BlockPos position) {
        this.owner = owner;
        this.level = level;
        this.position = position.immutable();
    }

    boolean stillValid(final Level currentLevel, final BlockPos currentPosition) {
        return currentLevel == this.level
            && currentPosition.equals(this.position)
            && this.level.getBlockEntity(this.position) == this.owner
            && this.owner.isStillValid();
    }

    // ---------------------------------------------- SerialInterface: reading

    @Override
    public boolean canRead() {
        return this.owner.isReceptionAvailable();
    }

    @Override
    public short peek() {
        this.syncCursor();
        final short[] currentFrame = this.owner.serialFrame();
        if (this.cursor < currentFrame.length) {
            return currentFrame[this.cursor];
        }
        return 0;
    }

    @Override
    public void skip() {
        this.syncCursor();
        final short[] currentFrame = this.owner.serialFrame();
        if (this.cursor < currentFrame.length) {
            this.cursor++;
        }
    }

    // ---------------------------------------------- SerialInterface: writing

    @Override
    public boolean canWrite() {
        return this.owner.isTransmitReady();
    }

    @Override
    public void write(final short value) {
        if (this.pendingCommand == 0) {
            this.beginCommand(value);
            return;
        }
        switch (this.pendingCommand) {
            case CMD_STRENGTH -> {
                this.owner.applyTransmittedStrength(value & 0xF);
                this.endCommand();
            }
            case CMD_REAL -> {
                this.accumulator[this.accumulatorIndex++] = value;
                if (this.accumulatorIndex >= this.accumulator.length) {
                    long bits = 0L;
                    for (final short word : this.accumulator) {
                        bits = bits << 16 | (long) word & 0xFFFFL;
                    }
                    double real = Double.longBitsToDouble(bits);
                    if (!Double.isFinite(real)) {
                        real = 0.0D;
                    }
                    this.owner.applyTransmittedValue(ChannelValue.real(real));
                    this.endCommand();
                }
            }
            case CMD_BOOL -> {
                this.owner.applyTransmittedValue(ChannelValue.bool(value != 0));
                this.endCommand();
            }
            case CMD_TEXT -> {
                if (value == 0) {
                    this.owner.applyTransmittedValue(ChannelValue.text(sanitizeText(this.textBuffer)));
                    this.endCommand();
                } else if (this.textBuffer.length() < TEXT_BUFFER_LIMIT) {
                    this.textBuffer.append((char) value);
                }
            }
            default -> this.endCommand();
        }
    }

    private void beginCommand(final short command) {
        switch (command) {
            case CMD_STRENGTH, CMD_REAL, CMD_BOOL -> {
                this.pendingCommand = command;
                this.accumulatorIndex = 0;
            }
            case CMD_TEXT -> {
                this.pendingCommand = command;
                this.textBuffer.setLength(0);
            }
            case CMD_CLEAR -> this.owner.applyClearTransmittedValue();
            default -> {
                // Unknown command words are ignored.
            }
        }
    }

    private void endCommand() {
        this.pendingCommand = 0;
        this.accumulatorIndex = 0;
        this.textBuffer.setLength(0);
    }

    // ------------------------------------------------------ SerialInterface

    @Override
    public void reset() {
        this.cursor = 0;
        this.endCommand();
    }

    @Override
    public void save(final CompoundTag tag) {
        tag.putInt(TAG_CURSOR, this.cursor);
        tag.putInt(TAG_FRAME_VERSION, this.frameVersion);
        tag.putShort(TAG_COMMAND, this.pendingCommand);
        tag.putInt(TAG_ACCUMULATOR_INDEX, this.accumulatorIndex);
        final int[] words = new int[this.accumulator.length];
        for (int index = 0; index < this.accumulator.length; index++) {
            words[index] = this.accumulator[index] & 0xFFFF;
        }
        tag.putIntArray(TAG_ACCUMULATOR, words);
        tag.putString(TAG_TEXT, this.textBuffer.toString());
    }

    @Override
    public void load(final CompoundTag tag) {
        this.cursor = Math.max(0, tag.getInt(TAG_CURSOR));
        this.frameVersion = tag.getInt(TAG_FRAME_VERSION);
        this.pendingCommand = tag.getShort(TAG_COMMAND);
        this.accumulatorIndex =
            Math.min(Math.max(0, tag.getInt(TAG_ACCUMULATOR_INDEX)), this.accumulator.length);
        final int[] words = tag.getIntArray(TAG_ACCUMULATOR);
        for (int index = 0; index < this.accumulator.length && index < words.length; index++) {
            this.accumulator[index] = (short) words[index];
        }
        this.textBuffer.setLength(0);
        this.textBuffer.append(tag.getString(TAG_TEXT));
        if (this.textBuffer.length() > TEXT_BUFFER_LIMIT) {
            this.textBuffer.setLength(TEXT_BUFFER_LIMIT);
        }
    }

    private void syncCursor() {
        final int currentVersion = this.owner.serialFrameVersion();
        if (currentVersion != this.frameVersion) {
            this.frameVersion = currentVersion;
            this.cursor = 0;
        }
    }

    // ------------------------------------------------------------ encoding

    /**
     * Encodes the current AFN reception into the read frame consumed by the
     * serial port module. See the class documentation for the layout.
     */
    static short[] encodeFrame(final ChannelReception reception) {
        final int strength = reception.strength();
        final Optional<ChannelReceivedValue> received = reception.value();
        if (received.isEmpty()) {
            return new short[]{KIND_NONE, 0, (short) strength, 0};
        }

        final ChannelReceivedValue value = received.get();
        final short kind;
        final short[] payload;

        if (value.value() instanceof final ChannelValue.Real real) {
            final List<Double> components = real.components();
            payload = new short[components.size() * 4];
            int index = 0;
            for (final double component : components) {
                final long bits = Double.doubleToLongBits(Double.isFinite(component) ? component : 0.0D);
                payload[index++] = (short) (bits >>> 48);
                payload[index++] = (short) (bits >>> 32);
                payload[index++] = (short) (bits >>> 16);
                payload[index++] = (short) bits;
            }
            kind = KIND_REAL;
        } else if (value.value() instanceof final ChannelValue.Text text) {
            final String content = text.value();
            payload = new short[content.length()];
            for (int index = 0; index < content.length(); index++) {
                payload[index] = (short) content.charAt(index);
            }
            kind = KIND_TEXT;
        } else if (value.value() instanceof final ChannelValue.Bool bool) {
            payload = new short[]{(short) (bool.value() ? 1 : 0)};
            kind = KIND_BOOL;
        } else {
            return new short[]{KIND_NONE, 0, (short) strength, 0};
        }

        final short[] encoded = new short[HEADER_WORDS + payload.length];
        encoded[0] = kind;
        encoded[1] = (short) payload.length;
        encoded[2] = (short) strength;
        encoded[3] = (short) (value.revision() & 0xFFFFL);
        System.arraycopy(payload, 0, encoded, HEADER_WORDS, payload.length);
        return encoded;
    }

    /**
     * Brings a raw short stream into compliance with the AFN text policy:
     * rejects the section sign, control characters (except newline), format
     * characters and surrogates, and caps the result at 1024 code points
     * (which also guarantees the 4096 UTF-8 byte envelope).
     */
    static String sanitizeText(final CharSequence raw) {
        final StringBuilder safe = new StringBuilder(raw.length());
        raw.codePoints()
            .filter(AfnSerialInterface::isSafeCodePoint)
            .limit(1024)
            .forEach(safe::appendCodePoint);
        return safe.toString();
    }

    private static boolean isSafeCodePoint(final int codePoint) {
        if (codePoint == 0xA7) {
            return false;
        }
        if (Character.isISOControl(codePoint) && codePoint != '\n') {
            return false;
        }
        final int type = Character.getType(codePoint);
        return type != Character.FORMAT && type != Character.SURROGATE;
    }
}
