package com.afntisbridge;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/**
 * The AFN serial transceiver block. Holds up to two AFN frequency boards that
 * define the channel this block transceives on. TIS-3D serial port modules
 * placed against it speak the AFN channel serial protocol.
 *
 * <p>Interaction model:</p>
 * <ul>
 *   <li>Right-click while holding an AFN frequency board: insert into the first
 *       free slot.</li>
 *   <li>Sneak right-click with an empty hand: eject the most recently inserted
 *       board.</li>
 *   <li>Hoppers and other item automation can access the board slots through
 *       the item handler capability.</li>
 * </ul>
 */
public final class SerialTransceiverBlock extends Block implements EntityBlock {

    public SerialTransceiverBlock(final Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(final BlockPos position, final BlockState state) {
        return new SerialTransceiverBlockEntity(position, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(
        final Level level, final BlockState state, final BlockEntityType<T> type) {
        if (level.isClientSide || type != ModRegistry.TRANSCEIVER_BLOCK_ENTITY.get()) {
            return null;
        }
        return (tickerLevel, tickerPosition, tickerState, blockEntity) -> {
            if (blockEntity instanceof final SerialTransceiverBlockEntity transceiver) {
                transceiver.serverTick();
            }
        };
    }

    @Override
    protected ItemInteractionResult useItemOn(
        final ItemStack stack, final BlockState state, final Level level, final BlockPos position,
        final Player player, final InteractionHand hand, final BlockHitResult hitResult) {

        if (SerialTransceiverBlockEntity.isFrequencyBoard(stack)
            && level.getBlockEntity(position) instanceof final SerialTransceiverBlockEntity transceiver) {

            if (!transceiver.hasFreeBoardSlot()) {
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            if (level.isClientSide) {
                return ItemInteractionResult.SUCCESS;
            }
            if (transceiver.insertBoard(stack)) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                level.playSound(null, position,
                    net.minecraft.sounds.SoundEvents.ITEM_FRAME_ADD_ITEM,
                    net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
                return ItemInteractionResult.SUCCESS;
            }
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(
        final BlockState state, final Level level, final BlockPos position,
        final Player player, final BlockHitResult hitResult) {

        if (player.isShiftKeyDown()
            && level.getBlockEntity(position) instanceof final SerialTransceiverBlockEntity transceiver) {

            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            final ItemStack ejected = transceiver.ejectBoard();
            if (!ejected.isEmpty()) {
                if (!player.addItem(ejected)) {
                    player.drop(ejected, false);
                }
                level.playSound(null, position,
                    net.minecraft.sounds.SoundEvents.ITEM_FRAME_REMOVE_ITEM,
                    net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 1.0F);
                return InteractionResult.CONSUME;
            }
        }
        return InteractionResult.PASS;
    }

    @Override
    public void onRemove(
        final BlockState state, final Level level, final BlockPos position,
        final BlockState newState, final boolean movedByPiston) {

        if (!state.is(newState.getBlock())
            && level.getBlockEntity(position) instanceof final SerialTransceiverBlockEntity transceiver) {
            transceiver.dropBoards();
            transceiver.shutdown();
        }
        super.onRemove(state, level, position, newState, movedByPiston);
    }
}
