package com.afntisbridge;

import li.cil.tis3d.api.serial.SerialInterface;
import li.cil.tis3d.api.serial.SerialInterfaceProvider;
import li.cil.tis3d.api.serial.SerialProtocolDocumentationReference;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;

import java.util.Optional;

/**
 * Registers the AFN channel serial protocol with TIS-3D. The protocol is
 * implemented by the serial transceiver block added by this mod; the wire
 * format is documented in the manual page "afn_channel.md" (served from this
 * mod's doc namespace, rendered in the TIS-3D manual's serial protocols tab).
 */
public final class AfnSerialInterfaceProvider implements SerialInterfaceProvider {

    private static final Component DOCUMENTATION_TITLE =
        Component.translatable("afntisbridge.manual.serial_protocols.afn");

    // Plain relative filename, resolved against the current manual page
    // (the serial protocols index, .../protocols/index.md) by Markdown Manual.
    // Our client-side NamespaceDocumentProvider("afntisbridge", "doc") then
    // serves it from assets/afntisbridge/doc/<lang>/protocols/afn_channel.md.
    // A namespaced link ("afntisbridge:...") would be treated as a relative
    // path, and the ':' would crash ResourceLocation validation.
    private static final SerialProtocolDocumentationReference DOCUMENTATION_REFERENCE =
        new SerialProtocolDocumentationReference(DOCUMENTATION_TITLE, "afn_channel.md");

    @Override
    public boolean matches(final Level level, final BlockPos position, final Direction side) {
        return !level.isClientSide
            && level.getBlockEntity(position) instanceof SerialTransceiverBlockEntity;
    }

    @Override
    public Optional<SerialInterface> getInterface(final Level level, final BlockPos position, final Direction side) {
        if (level.isClientSide
            || !(level.getBlockEntity(position) instanceof final SerialTransceiverBlockEntity transceiver)) {
            return Optional.empty();
        }
        return Optional.of(new AfnSerialInterface(transceiver, level, position));
    }

    @Override
    public Optional<SerialProtocolDocumentationReference> getDocumentationReference() {
        return Optional.of(DOCUMENTATION_REFERENCE);
    }

    @Override
    public boolean stillValid(
        final Level level, final BlockPos position, final Direction side, final SerialInterface serialInterface) {

        if (!(serialInterface instanceof final AfnSerialInterface bridgeInterface)) {
            return false;
        }
        return bridgeInterface.stillValid(level, position);
    }
}
