package com.afntisbridge;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ModRegistry {

    private static final DeferredRegister.Blocks BLOCKS =
        DeferredRegister.createBlocks(AfnTisBridge.MOD_ID);
    private static final DeferredRegister.Items ITEMS =
        DeferredRegister.createItems(AfnTisBridge.MOD_ID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AfnTisBridge.MOD_ID);

    // DeferredBlock extends DeferredHolder<Block, Block> and implements
    // Holder<Block>, which is what registerSimpleBlockItem expects on
    // NeoForge 1.21.1.
    public static final DeferredBlock<SerialTransceiverBlock> TRANSCEIVER_BLOCK =
        BLOCKS.register("afn_serial_transceiver", () -> new SerialTransceiverBlock(
            // Note: no .setId(...) here -- that API only exists in MC 1.21.2+.
            // On 1.21.1 the block id is assigned automatically by
            // DeferredRegister.Blocks when the block is registered.
            BlockBehaviour.Properties.of()
                .strength(1.8f, 3.0f)
                .sound(net.minecraft.world.level.block.SoundType.METAL)));

    // registerSimpleBlockItem returns DeferredItem<BlockItem> on 1.21.1.
    public static final DeferredItem<BlockItem> TRANSCEIVER_ITEM =
        ITEMS.registerSimpleBlockItem(TRANSCEIVER_BLOCK);

    public static final Supplier<BlockEntityType<SerialTransceiverBlockEntity>> TRANSCEIVER_BLOCK_ENTITY =
        BLOCK_ENTITIES.register("afn_serial_transceiver", () ->
            BlockEntityType.Builder.of(SerialTransceiverBlockEntity::new, TRANSCEIVER_BLOCK.get())
                .build(null));

    private ModRegistry() {
    }

    static void register(final IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
    }
}
