package com.afntisbridge;

import com.createafn.api.channel.ChannelValue;

/**
 * The channel-facing operations {@link AfnSerialInterface} needs from its
 * owning transceiver. Implemented by {@link SerialTransceiverBlockEntity};
 * extracted as an interface so the write state machine can be unit tested
 * without a Minecraft runtime.
 */
interface SerialChannelOwner {

    /** @return the decoded reception frame consumed by the read cursor. */
    short[] serialFrame();

    /** @return version of {@link #serialFrame()}; incremented on every change. */
    int serialFrameVersion();

    /** @return whether the channel currently carries a signal (strength &gt; 0). */
    boolean isReceptionAvailable();

    /** @return whether the serial port module may write to the channel. */
    boolean isTransmitReady();

    /** Sets the transmitted signal strength (0..15). */
    void applyTransmittedStrength(int strength);

    /** Transmits a typed value on the channel. */
    void applyTransmittedValue(ChannelValue value);

    /** Clears the transmitted typed value, keeping the current strength. */
    void applyClearTransmittedValue();

    /** @return whether the owning block entity is still live (not removed). */
    boolean isStillValid();
}
