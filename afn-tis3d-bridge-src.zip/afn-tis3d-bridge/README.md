# AFN Serial Bridge

Bridges **TIS-3D** serial port modules to **Create: Advanced Frequency Network
(AFN)** channels on Minecraft 1.21.1 / NeoForge.

## What it does

- Adds the **AFN Serial Transceiver** block. It holds up to two AFN frequency
  boards (right-click to insert, sneak right-click to eject) and opens a
  TRANSCEIVE channel endpoint through `AFNChannelApi` (public API, v1.1).
- Registers the serial protocol `afntisbridge:afn_transceiver` in TIS-3D's
  `tis3d:serial_interface_provider` registry. A serial port module placed
  against the transceiver reads and writes the channel.
- Ships a protocol manual page that appears in the TIS-3D manual's serial
  protocols tab (English and Chinese). The page is shipped under the
  `tis3d` asset namespace (the standard way to extend another mod's manual)
  with a fallback copy under this mod's own namespace.
- Recipe: shaped crafting, TIS-3D controller above an AFN mailbox
  (`data/afntisbridge/recipe/afn_serial_transceiver.json`).

## Wire protocol

Reading (channel → casing), a 4-word header `[kind, length, strength,
revision]` followed by the typed payload (REAL = 4 words per IEEE 754 double,
TEXT = UTF-16BE code units, BOOL = 1 word). Writing (casing → channel) is
command-prefixed: `1` strength, `2` real (4 words), `3` text (0x0000
terminated), `4` bool, `5` clear. Full spec:
`assets/afntisbridge/doc/en_us/protocols/afn_channel.md`.

## Source layout

```
src/main/java/com/afntisbridge/
  AfnTisBridge.java                 mod entry: serial provider + manual document provider
  ModRegistry.java                  block / item / block entity registration
  SerialTransceiverBlock.java       board insertion/ejection, ticking
  SerialTransceiverBlockEntity.java AFN endpoint lifecycle + reception cache
  SerialChannelOwner.java           owner interface (keeps the codec unit-testable)
  AfnSerialInterfaceProvider.java   TIS-3D serial protocol provider (link: afn_channel.md)
  AfnSerialInterface.java           the short <-> ChannelValue codec
```

Every completed write command is logged (`[AFN Serial Bridge] Transmitted ...`,
`Strength set ...`, `Cleared ...`) so protocol activity can be traced in
latest.log; dropped or rejected operations log warnings.

## Building (NeoForge MDK, ModDevGradle)

This project is laid out on top of the official
`MDK-1.21.1-ModDevGradle` template (ModDevGradle 2.0.148, Gradle 9.2.1
wrapper, NeoForge 21.1.252). To set it up from a fresh MDK download:

1. Extract `MDK-1.21.1-ModDevGradle-main.zip`.
2. Copy this project's files over it: `build.gradle`, `settings.gradle`,
   `gradle.properties`, `src/main/templates/`, `src/main/java/`,
   `src/main/resources/`.
3. Delete the MDK's example sources if they are still present
   (`src/main/java/com/example`, `src/main/resources/assets/examplemod`).
4. Copy the jars into `libs/`:
   - `tis3d-MC1.21.1-neoforge-2.0.0+fff58fd.jar`
   - `create_afn.jar`
   - `markdown_manual-MC1.21.1-neoforge-1.2.8+f9b4895.jar`
     (from Modrinth, provides `li.cil.manual.api` used by the client class)
5. Run `./gradlew build`. The jar ends up in `build/libs/afntisbridge-0.1.0.jar`.

`neoforge.mods.toml` is generated from `src/main/templates` via the
`generateModMetadata` task; do not put a static copy under
`src/main/resources/META-INF`.

For in-IDE testing with `runClient`, also uncomment the `localRuntime`
lines in `build.gradle` and drop the runtime dependency chains of both mods
(architectury, markdown_manual, Create 6 + ponder) into `run/mods`.

At runtime (real game or server) the full dependency chains of both mods
must be installed (architectury + markdown_manual for TIS-3D; Create 6 for
create_afn).

## Notes and limitations

- Use one serial port module per transceiver; concurrent writers interleave
  commands.
- Text is sanitized to AFN's character policy (no `§`, no control characters
  except newline, ≤ 1024 code points). Non-finite doubles are sent as 0.0.
- The endpoint is per-transceiver and persists its channel identity across
  reloads; revision counters restart when the transceiver is broken.
